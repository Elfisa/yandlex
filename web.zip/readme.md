# Интернет магазин

Предложение представляет собой интернет магазин.

## Installation

```pip install -r requirements.txt```

## Запуск
main.py

ADMIN:

login: admin@shop.ru

pass: 12345678
## API
```/api/v1/products/category-<category_id>```

Позволяет получить информацию о товарах соответствующих категорий

```api/v1/basket```

Позволяет получить информацию о товаров в корзине пользователя
